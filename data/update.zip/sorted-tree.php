<?php

class sortedTree {

    public $topNode;
    public $length;

    public $lowest = null;
    public $greatest = null;

    function __construct() {
        
        $this->length = 0;
    }

    function greatest() {

        if( $this->greatest != null )
            return $this->greatest;

        $tmp = $this->topNode;
        while( $tmp != null && $tmp->right != null ) {

            $tmp = $tmp->right;
        }

        $this->greatest = $tmp;
        return $tmp;
    }

    function lowest() {

        if( $this->lowest != null )
            return $this->lowest;

        $tmp = $this->topNode;
        while( $tmp != null && $tmp->left != null ) {

            $tmp = $tmp->left;
        }

        $this->lowest = $tmp;
        return $tmp;
    }

    function add($compare_value,$actual_value = null) {

        $actual_value = is_null($actual_value) ? $compare_value:$actual_value;

        if( is_null($this->topNode) ) {
            $this->topNode = new sortedNode($actual_value);
            $this->topNode->tree = $this;
            $this->length++;
            return $this->topNode;
        }

        $tmp = $this->topNode;
        while( $tmp != null ) {

            if( $tmp->value == $compare_value ) {

                $tmp->count++;
                return $tmp;
                break;

            }elseif( $compare_value > $tmp->value ) {

                if( $tmp->right == null ) {

                    $child = new sortedNode($actual_value,$tmp);

                    $tmp->right = $child;

                    $child->tree = $this;
                    $this->length++;
                    
                    if( $this->greatest != null && $this->greatest->value < $child->value )
                        $this->greatest = $child;
                    
                    return $child;
                    break;
                }else {

                    $tmp = $tmp->right;
                    continue;
                }

            }else {

                if( $tmp->left == null ) {

                    $child = new sortedNode($actual_value,$tmp);

                    $tmp->left = $child;
                    $child->tree = $this;
                    $this->length++;
                    
                    if( $this->lowest != null && $this->lowest->value < $child->value )
                        $this->lowest = $child;
                    
                    return $child;
                    break;
                }else {

                    $tmp = $tmp->left;
                    continue;
                }              
            }
        }
    }
}

class sortedNode {

    public $count = 1;

    public $value;

    public $parent = null;

    public $right = null;
    public $left = null;
    
    public $tree;

    function __construct($value,$parent = null,$right = null,$left = null) {

        $this->value = $value;

        $this->parent = $parent;

        $this->left = $left;
        $this->right = $right;
    }

    function remove() {
        
        $this->count--;

        if( $this->count <= 0 ) {
            
            $this->tree->length--;
            
            if( $this->tree->lowest != null && $this->tree->lowest->value == $this->value )
                $this->tree->lowest = null;

            if( $this->tree->greatest != null && $this->tree->greatest->value == $this->value )
                $this->tree->greatest = null;

            if( $this->right == null && $this->left == null ) {
                if( $this->parent == null ) {
                    
                    $this->tree->topNode = null;
                }elseif( $this->parent->left != null && $this->parent->left->value == $this->value ) {
                    $this->parent->left = null;
                }else {
                    $this->parent->right = null;
                }
            }elseif( $this->right != null && $this->left != null ) {

                //Set Right Node as the Parent.
                if( $this->parent == null ) {
                    
                    $this->tree->topNode = $this->right;
                    $this->right->parent = null;
                }elseif( $this->parent->left != null && $this->parent->left->value == $this->value ) {

                    $this->parent->left = $this->right;
                    $this->right->parent = $this->parent;
                }else {

                    $this->parent->right = $this->right;
                    $this->right->parent = $this->parent;
                }

                //Then Set The Left Node To It.
                $tmp = $this->right;
                while( $tmp != null ) {

                    if( $this->left != null && $this->left->value == $tmp->value ) {

                        $tmp->count++;
                        return;
                        break;
                    }elseif( $this->left->value > $tmp->value ) {

                        if( $tmp->right == null ) {
                            $tmp->right = $this->left;
                            $this->left->parent = $tmp->right;
                            return;
                            break;
                        }else {

                            $tmp = $tmp->right;
                            continue;
                        }
                    }else {

                        if( $tmp->left == null ) {

                            $tmp->left = $this->left;
                            $this->left->parent = $tmp->left;
                            return;
                            break;
                        }else {

                            $tmp = $tmp->left;
                            continue;
                        }
                    }
                }
            }else {

                if( $this->parent == null ) {

                    $this->tree->topNode = $this->right == null ? $this->left:$this->right;
                    
                    if( $this->right == null )
                        $this->left->parent = null;
                    else
                        $this->right->parent = null;
                              
                }elseif( $this->parent->left != null && $this->parent->left->value == $this->value ) {

                    if( $this->left != null ) {

                        $this->parent->left = $this->left;
                        $this->left->parent = $this->parent;
                    }else {

                        $this->parent->left = $this->right;
                        $this->right->parent = $this->parent;
                    }
                }else {

                    if( $this->right != null ) {

                        $this->parent->right = $this->right;
                        $this->right->parent = $this->parent;
                    }else {

                        $this->parent->right = $this->left;
                        $this->left->parent = $this->parent;
                    }
                }
            }
        }
    }
}

$tree = new sortedTree;

$tree->add(3);
$four = $tree->add(4);
$tree->add(6);
$tree->add(2);

//$four->remove();

var_dump($tree->greatest()->value);
?>